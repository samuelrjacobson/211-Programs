
public class Lab2part2 {

	public static void main(String[] args) {
		

	}
	
	public static boolean isPrime (BigInteger num) {
		
	}

}
