public class UnknownOperatorException extends Exception {
	public UnknownOperatorException() {
		super();
	}
	public UnknownOperatorException(String s) {
		super(s);
	}
   
}
